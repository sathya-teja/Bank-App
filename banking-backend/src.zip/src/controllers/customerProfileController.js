// src/controllers/customerProfileController.js
import Joi from 'joi';
import CustomerProfile from '../models/CustomerProfile.js';

const profileSchema = Joi.object({
  fullName: Joi.string().min(2).max(150).required(),
  phone: Joi.string().min(7).max(15).required(),
  dob: Joi.date().required(),
  address: Joi.object({
    line1: Joi.string().allow('').optional(),
    line2: Joi.string().allow('').optional(),
    city: Joi.string().allow('').optional(),
    state: Joi.string().allow('').optional(),
    postalCode: Joi.string().allow('').optional()
  }).optional(),
  aadhar: Joi.string().min(8).max(20).required(),
  pan: Joi.string().min(5).max(20).required(),
  photoUrl: Joi.string().uri().optional()
});

export async function createOrUpdateProfile(req, res) {
  // 🚫 Block admins from creating/updating profiles
  if (req.user.role === 'admin') {
    return res.status(403).json({ error: 'Admins do not require KYC' });
  }

  const { error, value } = profileSchema.validate(req.body);
  if (error) return res.status(400).json({ error: error.message });

  try {
    let profile = await CustomerProfile.findOne({ userId: req.user.id });

    if (!profile) {
      // 🆕 New profile → always pending
      profile = new CustomerProfile({
        ...value,
        userId: req.user.id,
        kycStatus: 'pending',
      });
    } else {
      // ✏️ Existing profile → update fields
      const { aadhar, pan, ...rest } = value;

      // Only reset to pending if Aadhar or PAN changed
      if (profile.aadhar !== aadhar || profile.pan !== pan) {
        profile.kycStatus = 'pending';
      }

      profile.fullName = rest.fullName;
      profile.phone = rest.phone;
      profile.dob = rest.dob;
      profile.address = rest.address;
      profile.photoUrl = rest.photoUrl;
      profile.aadhar = aadhar;
      profile.pan = pan;
    }

    const saved = await profile.save();
    res.status(profile.isNew ? 201 : 200).json({ ok: true, profile: saved });
  } catch (e) {
    if (e.code === 11000) {
      return res.status(409).json({ error: 'Duplicate identity field' });
    }
    res.status(500).json({ error: e.message });
  }
}

export async function getMyProfile(req, res) {
  if (req.user.role === 'admin') {
    return res.status(403).json({ error: 'Admins do not have KYC profiles' });
  }

  const profile = await CustomerProfile.findOne({ userId: req.user.id });
  if (!profile) return res.status(404).json({ error: 'Profile not found' });
  res.json({ ok: true, profile });
}

// Admin can still list and update others’ profiles
export async function listProfiles(req, res) {
  const profiles = await CustomerProfile.find().limit(200);
  res.json({ ok: true, profiles });
}

export async function updateKycStatus(req, res) {
  const { id } = req.params;
  const { kycStatus } = req.body;
  if (!['pending', 'verified', 'rejected'].includes(kycStatus))
    return res.status(400).json({ error: 'Invalid status' });

  const profile = await CustomerProfile.findByIdAndUpdate(id, { kycStatus }, { new: true });
  if (!profile) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true, profile });
}

// pending kyc requests only for admin
export async function listPendingProfiles(req, res) {
  try {
    const profiles = await CustomerProfile.find({ kycStatus: 'pending' }).limit(200);
    res.json({ ok: true, profiles });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
